//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by user259865 on 5/17/24.
//

import UIKit
import CoreData
import Photos

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {

    @IBOutlet weak var imgProfile: UIImageViewX!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var lblEmailAddress: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    // Create variable for database manager class
    private let manager = DatabaseManger()
    private var imgSelectedORNot: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Add Users"
        imgProfile.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
        imgProfile.addGestureRecognizer(tapGesture)
    }
   
    @IBAction func RegisterMethod(_ sender: UIButtonX) {
        guard let strFirstName = txtFirstName.text, !strFirstName.isEmpty else {
            self.showAlert(title: "", message: "First Name is empty")
            return
        }
        guard let strLastName = txtLastName.text, !strLastName.isEmpty else {
            self.showAlert(title: "", message: "Last Name is empty")
            return
        }
        guard let strEmailAddress = lblEmailAddress.text, !strEmailAddress.isEmpty else {
            self.showAlert(title: "", message: "Email Address is empty")
            return
        }
        guard let strPassword = txtPassword.text, !strPassword.isEmpty else {
            self.showAlert(title: "", message: "Password is empty")
            return
        }
        
        if !imgSelectedORNot {
            showAlert(title: "", message: "Please select any image for profile")
            return
        }
        
        let imageName = UUID().uuidString
        let user = UserModel(firstName: txtFirstName.text!,
                             lastName: txtLastName.text!,
                             emailAddress: lblEmailAddress.text!,
                             password: txtPassword.text! ,
                             imageName: imageName)
     
        guard let imgPro = self.imgProfile.image else {
                showAlert(title: "", message: "No image found in imgProfile")
                return
            }

            let success = Utils.saveImageToDocumentDirectory(img: imgPro, imageName: imageName)
            if success {
                print("Image saved...")
               // showAlert(title: "", message: "Image successfully saved in document directory")
                manager.addUsers(user)
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }
            } else {
                showAlert(title: "", message: "Image failed to save.")
            }
    }
    
    func showAlert(title: String, message: String) {
           let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
           let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
           alertController.addAction(okAction)
           present(alertController, animated: true, completion: nil)
    }
}
// MARK: - UIImagePickerControllerDelegate
extension ViewController {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Set the selected image to the imageView
              imgProfile.image = selectedImage
            self.imgSelectedORNot = true
        }
           picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
extension ViewController {
    @objc func imageViewTapped() {
         // Check the authorization status
         let status = PHPhotoLibrary.authorizationStatus()
         if status == .denied || status == .restricted {
             // Show an alert to tell users to enable permission in settings
             showAlertForPhotoLibraryAccess()
         } else if status == .notDetermined {
             // Request permission
             PHPhotoLibrary.requestAuthorization { status in
                 if status == .authorized {
                     self.presentImagePickerController()
                 } else {
                     self.showAlertForPhotoLibraryAccess()
                 }
             }
         } else {
             // Authorized
             presentImagePickerController()
         }
     }
    
    func presentImagePickerController() {
           DispatchQueue.main.async {
               let imagePickerController = UIImagePickerController()
               imagePickerController.delegate = self
               imagePickerController.sourceType = .photoLibrary
               self.present(imagePickerController, animated: true, completion: nil)
           }
    }
    
    func showAlertForPhotoLibraryAccess() {
           let alert = UIAlertController(title: "Access Required", message: "Please enable photo library access in settings.", preferredStyle: .alert)
           alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
           present(alert, animated: true, completion: nil)
    }
}
