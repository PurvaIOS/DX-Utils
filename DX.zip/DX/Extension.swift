//
//  Extension.swift
//  MVVMUrlSession
//
//  Created by user259865 on 5/17/24.
//

import Foundation
import UIKit

extension UIImageView{
    func loadImage(from urlString: String, completion: @escaping (UIImage?) -> Void) {
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                // Check for errors
                if let error = error {
                    print("Error loading image: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        completion(nil)
                    }
                    return
                }
                
                // Check if data is available
                guard let imageData = data else {
                    print("No image data received")
                    DispatchQueue.main.async {
                        completion(nil)
                    }
                    return
                }
                
                // Create UIImage from the downloaded data
                let image = UIImage(data: imageData)
                DispatchQueue.main.async {
                    completion(image)
                }
            }.resume() // Don't forget to resume the task
        } else {
            print("Invalid URL")
            completion(nil)
        }
    }
}
